from django.apps import AppConfig


class IntroConfig(AppConfig):
    name = 'postal_card'
